import React from 'react';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import Grid from '@mui/material/Grid';
import DialogTitle from '@mui/material/DialogTitle';
import TextField from '@mui/material/TextField';
import RefreshOutlinedIcon from '@mui/icons-material/RefreshOutlined';

function AddDialog({
    cust_id, open, open1, open2, open3, rows, business_code, cust_number, clear_date, 
    buisness_year, doc_id, posting_date, document_create_date, due_in_date, 
    invoice_currency, document_type, posting_id, total_open_amount, baseline_create_date, 
    cust_payment_terms, invoice_id, changeHandler, searchHandler, handleClickOpen, handleClose, 
    handleClickOpen1, handleClose1, handleClickOpen2, handleClose2, handleClickOpen3, handleClose3
}) {

    return <>
        <div>
            <ButtonGroup variant="outlined" aria-label="outlined button group" sx={{width:'40%', p:3}}>
            <Button variant="contained" fullWidth sx={{backgroundColor:"#14aff1", color:"white", borderRadius:2}} disableRipple>Predict</Button>

            <Button fullWidth sx={{borderColor:"#14aff1", color:"white", borderRadius:2}}>Analytics View</Button>
          
            <Button fullWidth onClick={handleClickOpen3} sx={{borderColor:"#14aff1", color:"white", borderRadius:2}}>Advance Search</Button>
            <Dialog fullWidth maxWidth='sm' open={open3} onClose={handleClose3}>
            <DialogTitle sx={{color: 'white', backgroundColor: '#283d4a'}}>Advance Search</DialogTitle>
                <DialogContent sx={{color: 'white', backgroundColor: '#283d4a'}}>
                <DialogContentText>
                    <Grid container spacing={{xs: 2}}>
                        <Grid item xs={6}>
                            <TextField
                                name="doc_id"
                                margin="dense"
                                id="doc_id"
                                label="Document ID"
                                value={doc_id}
                                onChange={changeHandler}
                                type="text"
                                variant="standard"
                                fullWidth

                                sx={{
                                    backgroundColor: "white", 
                                    borderRadius: 1
                                }}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <TextField
                                name="invoice_id"
                                margin="dense"
                                id="invoice_id"
                                label="Invoice ID"
                                value={invoice_id}
                                onChange={changeHandler}
                                type="text"
                                variant="standard"
                                fullWidth

                                sx={{
                                    backgroundColor: "white", 
                                    borderRadius: 1
                                }}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <TextField
                                name="cust_number"
                                margin="dense"
                                id="cust_number"
                                label="Customer Number"
                                value={cust_number}
                                onChange={changeHandler}
                                type="text"
                                variant="standard"
                                fullWidth

                                sx={{
                                    backgroundColor: "white", 
                                    borderRadius: 1
                                }}
                            />
                        </Grid>

                        <Grid item xs={6}>
                            <TextField
                                name="buisness_year"
                                margin="dense"
                                id="buisness_year"
                                label="Business Year"
                                value={buisness_year}
                                onChange={changeHandler}
                                type="text"
                                variant="standard"
                                fullWidth

                                sx={{
                                    backgroundColor: "white", 
                                    borderRadius: 1
                                }}
                            />
                        </Grid>

                    </Grid>
                </DialogContentText>
            </DialogContent>
            <DialogActions sx={{backgroundColor: '#283d4a'}}>
                <Button variant="outlined" fullWidth color='inherit' onClick={() => handleClose3(true)} sx={{color:"white"}}>search</Button>
                <Button variant="outlined" fullWidth color='inherit' onClick={() => handleClose3(false)} sx={{color:"white"}}>Cancel</Button>
            </DialogActions>
            </Dialog>
            </ButtonGroup>
            
            <Button variant="outlined" onClick={() => window.location.reload(false)} sx={{m:-2, borderColor:"#14aff1"}}><RefreshOutlinedIcon color="primary"/></Button>

            <TextField 
                
                name="cust_number"
                margin="dense"
                label="Search Customer ID" 
                id="cust_number"
                value={cust_id}
                onChange={searchHandler}
                type="text"
                variant="filled"

                sx={{
                    m:3,
                    borderRadius: 3,
                    backgroundColor: "white"
                }}
            />
            
            <ButtonGroup variant="outlined" aria-label="outlined button group" sx={{width:'30%'}}>
            <Button fullWidth onClick={handleClickOpen} sx={{borderColor:"#14aff1", color:"white", borderRadius:1}}>ADD</Button>
            <Dialog fullWidth maxWidth="xl" open={open} onClose={handleClose}>
            <DialogTitle sx={{color: 'white', backgroundColor: '#283d4a'}}>Add</DialogTitle>
            <DialogContent sx={{color: 'white', backgroundColor: '#283d4a'}}>
            <DialogContentText>
                <Grid container spacing={{xs: 2}}>
                    <Grid item xs={3}>
                        <TextField
                            name="business_code"
                            margin="dense"
                            id="business_code"
                            label="Business Code"
                            value={business_code}
                            onChange={changeHandler}
                            type="text"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>
                
                    <Grid item xs={3}>
                        <TextField
                        name="cust_number"
                        margin="dense"
                        id="cust_number"
                        label="Customer Number"
                        value={cust_number}
                        onChange={changeHandler}
                        type="number"
                        variant="standard"
                        fullWidth

                        sx={{
                        m:1,
                        backgroundColor: "white", 
                        borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <TextField
                            name="clear_date"
                            margin="dense"
                            id="clear_date"
                            label="Clear Date"
                            value={clear_date}
                            onChange={changeHandler}
                            type="date"
                            variant="standard"
                            fullWidth
                            focused

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>
                

                    <Grid item xs={3}>
                        <TextField
                            name="buisness_year"
                            margin="dense"
                            id="buisness_year"
                            label="Business Year"
                            value={buisness_year}
                            onChange={changeHandler}
                            type="number"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                    <TextField
                        name="doc_id"
                        margin="dense"
                        id="doc_id"
                        label="Document id"
                        value={doc_id}
                        onChange={changeHandler}
                        type="text"
                        variant="standard"
                        fullWidth

                        sx={{
                        m:1,
                        backgroundColor: "white", 
                        borderRadius: 1}}
                    />
                    </Grid>
                
                    <Grid item xs={3}>
                    <TextField
                        name="posting_date"
                        margin="dense"
                        id="posting_date"
                        label="Posting Date"
                        value={posting_date}
                        onChange={changeHandler}
                        type="date"
                        variant="standard"
                        fullWidth
                        focused


                        sx={{
                        m:1,
                        backgroundColor: "white", 
                        borderRadius: 1}}
                    />
                    </Grid>
                
                    <Grid item xs={3}>
                    <TextField
                        
                        name="document_create_date"
                        margin="dense"
                        id="document_create_date"
                        label="Document Create Date"
                        value={document_create_date}
                        onChange={changeHandler}
                        type="date"
                        variant="standard"
                        fullWidth
                        focused


                        sx={{
                        m:1,
                        backgroundColor: "white", 
                        borderRadius: 1}}
                    />
                    </Grid>
                
                    <Grid item xs={3}>
                        <TextField
                            name="due_in_date"
                            margin="dense"
                            id="due_in_date"
                            label="Due in Date"
                            value={due_in_date}
                            onChange={changeHandler}
                            type="date"
                            variant="standard"
                            fullWidth
                            focused


                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <TextField
                            name="invoice_currency"
                            margin="dense"
                            id="invoice_currency"
                            label="Invoice Currency"
                            value={invoice_currency}
                            onChange={changeHandler}
                            type="text"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <TextField
                            name="document_type"
                            margin="dense"
                            id="document_type"
                            label="Document Type"
                            value={document_type}
                            onChange={changeHandler}
                            type="text"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <TextField
                            name="posting_id"
                            margin="dense"
                            id="posting_id"
                            label="Posting id"
                            value={posting_id}
                            onChange={changeHandler}
                            type="number"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <TextField
                            name="total_open_amount"
                            margin="dense"
                            id="total_open_amount"
                            label="Total Open Amount"
                            value={total_open_amount}
                            onChange={changeHandler}
                            type="number"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <TextField
                            name="baseline_create_date"
                            margin="dense"
                            id="baseline_create_date"
                            label="Baseline Create Date"
                            value={baseline_create_date}
                            onChange={changeHandler}
                            type="date"
                            variant="standard"
                            fullWidth
                            focused


                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                    <Grid item xs={3}>
                        <TextField
                            name="cust_payment_terms"
                            margin="dense"
                            id="cust_payment_terms"
                            label="Customer Payment Terms"
                            value={cust_payment_terms}
                            onChange={changeHandler}
                            type="text"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>
            
                    <Grid item xs={3}>
                        <TextField
                            name="invoice_id"
                            margin="dense"
                            id="invoice_id"
                            label="Invoice id"
                            value={invoice_id}
                            onChange={changeHandler}
                            type="number"
                            variant="standard"
                            fullWidth

                            sx={{
                            m:1,
                            backgroundColor: "white", 
                            borderRadius: 1}}
                        />
                    </Grid>

                </Grid>
            </DialogContentText>
            </DialogContent>

            <DialogActions sx={{backgroundColor: '#283d4a'}}>
                <Button variant="outlined" fullWidth color='inherit' onClick={() => handleClose(true)} sx={{color:"white"}}>ADD</Button>
                <Button variant="outlined" fullWidth color='inherit' onClick={() => handleClose(false)} sx={{color:"white"}}>Cancel</Button>
            </DialogActions>
            </Dialog>

            <Button fullWidth onClick={()=>handleClickOpen2(false)} sx={{color:"white", borderRadius:1}} disableElevation={!(rows==1)}>EDIT</Button>
            <Dialog fullWidth maxWidth='sm' open={open2} onClose={handleClose2}>
            <DialogTitle sx={{color: 'white', backgroundColor: '#283d4a'}}>Edit</DialogTitle>
                <DialogContent sx={{color: 'white', backgroundColor: '#283d4a'}}>
                <DialogContentText>
                    <Grid container spacing={{xs: 5}}>
                        <Grid item xs={5}>
                            <TextField
                                autoFocus
                                name="invoice_currency"
                                margin="dense"
                                id="invoice_currency"
                                label="Invoice Currency"
                                value={invoice_currency}
                                onChange={changeHandler}
                                type="text"
                                variant="standard"
                                fullWidth

                                sx={{
                                    backgroundColor: "white", 
                                    borderRadius: 1
                                }}
                            />
                        </Grid>

                        <Grid item xs={5}>
                            <TextField
                                name="cust_payment_terms"
                                margin="dense"
                                id="cust_payment_terms"
                                label="Customer Payment Terms"
                                value={cust_payment_terms}
                                onChange={changeHandler}
                                type="text"
                                variant="standard"
                                fullWidth

                                sx={{
                                    backgroundColor: "white", 
                                    borderRadius: 1
                                }}
                            />
                        </Grid>

                    </Grid>
                </DialogContentText>
            </DialogContent>
            <DialogActions sx={{backgroundColor: '#283d4a'}}>
                <Button variant="outlined" fullWidth color='inherit' onClick={() => handleClose2(true)} sx={{color:"white"}}>Edit</Button>
                <Button variant="outlined" fullWidth color='inherit' onClick={() => handleClose2(false)} sx={{color:"white"}}>Cancel</Button>
            </DialogActions>
            </Dialog>

            <Button fullWidth onClick={handleClickOpen1} sx={{borderColor:"#14aff1", color:"white", borderRadius:1}}>DELETE</Button>
            <Dialog open={open1} onClose={handleClose1}>
                <DialogTitle sx={{color: 'white', backgroundColor: '#283d4a'}}>Delete Records ?</DialogTitle>
                <DialogContent sx={{color: 'white',backgroundColor: '#283d4a'}}>
                    <DialogContentText sx={{color: 'white',backgroundColor: '#283d4a'}}>
                        Are you sure you want to delete these record[s]?
                    </DialogContentText>
                </DialogContent>
                <DialogActions sx={{backgroundColor: '#283d4a'}}>
                <Button variant="outlined" fullWidth color='inherit' onClick={()=>handleClose1(false)} sx={{color:"white"}}>Cancel</Button>
                <Button variant="outlined" fullWidth color='inherit' onClick={()=>handleClose1(true)} sx={{color:"white"}}>Delete</Button>
                </DialogActions>
            </Dialog>
            </ButtonGroup>
        </div>
    </>
}
  
export default AddDialog;