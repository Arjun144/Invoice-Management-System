import { useEffect, useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { addInvoice, getData , updateInvoice, deleteInvoice, searchInvoice } from '../services/Data';
import AddDialog from './AddDialog';

  
function MyGrid(){

  const [data, setData] = useState([]);
  const [columns, setColumns] = 
  useState(
      [
        {field:"sl_no", headerName: 'Sl no', width: 70}, 
        {field:"business_code", headerName:"Business Code", width: 130},
        {field:"cust_number", headerName:"Customer Number", width: 140},
        {field:"clear_date", headerName:"Clear Date", width: 130},
        
        {field:"buisness_year", headerName:"Business Year", width: 130},
        {field:"doc_id", headerName:"Document ID", width: 130},
        {field:"posting_date", headerName:"Posting Date", width: 130},
        {field:"document_create_date", headerName:"Document Create Date", width: 130},

        {field:"due_in_date", headerName:"Due Date", width: 130},
        {field:"invoice_currency", headerName:"Invoice Currency", width: 130},
        {field:"document_type", headerName:"Document Type", width: 130},
        {field:"posting_id", headerName:"Posting ID", width: 130},
        
        {field:"total_open_amount", headerName:"Total Open Amount", width: 130},
        {field:"baseline_create_date", headerName:"Baseline Create Date", width: 130},
        
        {field:"cust_payment_terms", 
        headerName:"Customer Payment Terms", 
        width: 130,
        },

        {field:"invoice_id", headerName:"Invoice ID", width: 130}
      ]
  );

  const [invoice, setInvoice] = useState({ 
    business_code: '',
    cust_number: '',
    clear_date: '',
    buisness_year: '',
    doc_id: '',
    posting_date: '',
    document_create_date: '',
    due_in_date: '',
    invoice_currency: '',
    document_type: '',
    posting_id: '',
    total_open_amount: '',
    baseline_create_date: '',
    cust_payment_terms: '',
    invoice_id: ''
  });

  const {sl_no, business_code, cust_number, clear_date, buisness_year, doc_id,
    posting_date, document_create_date, due_in_date, invoice_currency, document_type,
    posting_id, total_open_amount, baseline_create_date, cust_payment_terms, invoice_id} = invoice;

  const changeHandler = (e) =>{
    const { name, value } = e.target;
    setInvoice({ ...invoice, [name]: value })
  }

  const [cust_id, setCustid] = useState("");
  
  function search(rows){
    return rows.filter(
      (row) => row.cust_number.toString().toLowerCase().indexOf(cust_id.toLowerCase()) > -1);
  }

  const searchHandler = (e) =>{
    setCustid(e.target.value)
  }


  const [selectionModel, setSelectionModel] = useState([]);

  const deleteHandler =() => {
      let del = data.filter((row) => !selectionModel.includes(row.sl_no));
      setData(del);
  }

  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };
  
  const handleClose = async (add) => {
    if(add){
      let response = await addInvoice(invoice);
      
        setInvoice({
          business_code: '',
          cust_number: '',
          clear_date: '',
          buisness_year: '',
          doc_id: '',
          posting_date: '',
          document_create_date: '',
          due_in_date: '',
          invoice_currency: '',
          document_type: '',
          posting_id: '',
          total_open_amount: '',
          baseline_create_date: '',
          cust_payment_terms: '',
          invoice_id: ''
      })
      
    }
    setOpen(false);
  };

  const [open1, setOpen1] = useState(false);

  const handleClickOpen1 = () => {
    setOpen1(true);
  };
  
  const handleClose1 = (del) => {
    if(del){
      deleteHandler();
    }
    setOpen1(false);
  };

  const [open2, setOpen2] = useState(false);

  let rows = data.filter((row) => selectionModel.includes(row.sl_no));

  const handleClickOpen2 = () => {
    if(rows.length==1){
      setInvoice(rows[0]);
      setOpen2(true);
    }
  };
  
  const handleClose2 = async (update) => {
    if(update){
      let response = await updateInvoice({sl_no, invoice_currency, cust_payment_terms})
    }
    setOpen2(false);
    window.location.reload(false)
  };

  const [open3, setOpen3] = useState(false);

  const handleClickOpen3 = () => {
    setOpen3(true);
  };
  
  const handleClose3 = async (find) => {
    if(find){
      let response = await searchInvoice(invoice);
      
      setInvoice({
        cust_number: '',
        buisness_year: '',
        doc_id: '',
        invoice_id: ''
      })
    }
    setOpen3(false);
  };

  const [open4, setOpen4] = useState(false);

  const handleClickOpen4 = () => {
    setOpen4(true);
  };
  
  const handleClose4 = () => {
    setOpen4(false);
  };

  const [pageSize, setPageSize] = useState(5);
  
  useEffect(async () => {
      setData(await getData());
  }, [open, open2, open3]);

  return <>

    <div style={{ height: 265, width: '100%' }}>

    <AddDialog 

        cust_id={cust_id}
        
        open={open}
        open1={open1}
        open2={open2}
        open3={open3}

        business_code={business_code} 
        cust_number={cust_number}
        clear_date={clear_date}
        buisness_year={buisness_year}

        doc_id={doc_id}
        posting_date={posting_date}
        document_create_date={document_create_date}
        due_in_date={due_in_date}

        invoice_currency={invoice_currency}
        document_type={document_type}
        posting_id={posting_id}
        total_open_amount={total_open_amount}

        baseline_create_date={baseline_create_date}
        cust_payment_terms={cust_payment_terms}
        invoice_id={invoice_id}

        rows={rows.length}

        changeHandler={changeHandler}
        searchHandler={searchHandler}

        handleClickOpen={handleClickOpen}
        handleClose={handleClose}

        handleClickOpen1={handleClickOpen1}
        handleClose1={handleClose1}
        
        handleClickOpen2={handleClickOpen2}
        handleClose2={handleClose2}

        handleClickOpen3={handleClickOpen3}
        handleClose3={handleClose3}
      
      />

      <DataGrid

        rows={search(data)}
        rowHeight={25} 
        columns={columns}
        pageSize={ pageSize }
        onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
        rowsPerPageOptions={[5, 10, 20]}
        pagination
        getRowId={(row) => row.sl_no}
        checkboxSelection
        onSelectionModelChange={(rows) => {
          setSelectionModel(rows);
        }}

        sx={{
          boxShadow: 2,
          border: 2,
          color: 'white',
          borderColor: "#283d4a",
          '& .MuiDataGrid-cell:hover': {
            color: 'primary.main',
          },
          '& .MuiCheckbox-root svg': {
            color:'white'
          }
        }}
      />
    </div>
  </>
}
export default MyGrid;