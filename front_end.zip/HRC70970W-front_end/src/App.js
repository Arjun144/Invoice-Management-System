import './App.css'
import logo from './hrclogo.svg'
import logo1 from './abc product.svg'
import MyGrid from './components/MyGrid';

function App() {
  return <>
    <div className="App">
        <img src = { logo1 } alt="ABC" />
        <img src = { logo } className="App-logo" alt="hrc" />
      <header className="App-header">
        <p>Invoice List</p>
      </header>
      <div className="App-body">
        <MyGrid />
      </div>
    </div>
    <footer className='App-footer'>
        <p><a href='https://www.highradius.com/privacy-policy/'>Privacy Policy.</a>| © 2022 HighRadius Corporation. All rights reserved.</p>
    </footer>
  </>
}

export default App;
